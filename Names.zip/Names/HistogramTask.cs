﻿using System;
using System.Linq;

namespace Names
{
    internal static class HistogramTask
    {
        public static HistogramData GetBirthsPerDayHistogram(NameData[] names, string name)
        {
            var newNames = names
                .Where(x => x.Name == name);

            var days = new string[31];
            for (var y = 0; y < days.Length; y++)
                days[y] = (y + 1).ToString();
            var birthsCounts = new double[31];
            foreach (var name1 in newNames)
            {
                if (name1.BirthDate.Day != 1)
                    birthsCounts[name1.BirthDate.Day - 1]++;
                else
                    continue;
            }
            return new HistogramData(
                string.Format("Рождаемость людей с именем '{0}'", name),
                days,
                birthsCounts);
        }
    }
}